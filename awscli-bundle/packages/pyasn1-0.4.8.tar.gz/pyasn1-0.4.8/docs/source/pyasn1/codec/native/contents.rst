
Native Python types
-------------------

.. autofunction:: pyasn1.codec.native.encoder.encode(asn1Value)

.. autofunction:: pyasn1.codec.native.decoder.decode(pyObject, asn1Spec)
