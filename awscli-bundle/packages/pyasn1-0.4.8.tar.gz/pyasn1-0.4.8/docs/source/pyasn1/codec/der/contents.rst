
Distinguished Encoding Rules
----------------------------

.. autofunction:: pyasn1.codec.der.encoder.encode(value, asn1Spec=None)

.. autofunction:: pyasn1.codec.der.decoder.decode(substrate, asn1Spec=None)
