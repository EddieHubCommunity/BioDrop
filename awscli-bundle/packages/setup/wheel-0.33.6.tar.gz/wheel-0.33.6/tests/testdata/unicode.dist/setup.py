# coding: utf-8
from setuptools import setup

setup(name='unicode.dist',
      version='0.1',
      description=u'A testing distribution \N{SNOWMAN}',
      packages=['unicodedist']
      )
